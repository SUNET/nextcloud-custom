/*! For license information please see autoredirect.js.LICENSE.txt */
document.addEventListener("DOMContentLoaded",(()=>{const e=document.getElementById("redirectLink");e&&e.click()}));
//# sourceMappingURL=autoredirect.js.map