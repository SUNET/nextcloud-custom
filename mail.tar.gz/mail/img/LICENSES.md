# Licenses
## mail.svg
- Created by: Google
- License: Apache License, Version 2.0
- Link: https://fonts.google.com/icons?selected=Material%20Icons%3Aemail%3A

## favicon-mask.svg
- Created by: Google
- License: Apache License, Version 2.0
- Link: https://fonts.google.com/icons?selected=Material%20Icons%3Amark_email_unread%3A

## favicon-notification.png
- Created by: Google
- License: Apache License, Version 2.0
- Link: https://fonts.google.com/icons?selected=Material%20Icons%3Amark_email_unread%3A

## favicon-notification.svg
- Created by: Google
- License: Apache License, Version 2.0
- Link: https://fonts.google.com/icons?selected=Material%20Icons%3Amark_email_unread%3A

## favicon-touch-notification.svg
- Created by: Google
- License: Apache License, Version 2.0
- Link: https://fonts.google.com/icons?selected=Material%20Icons%3Amark_email_unread%3A

## favicon-touch.svg
- Created by: Google
- License: Apache License, Version 2.0
- Link: https://fonts.google.com/icons?selected=Material%20Icons%3Aemail%3A

## favicon.svg
- Created by: Google
- License: Apache License, Version 2.0
- https://fonts.google.com/icons?selected=Material%20Icons%3Aemail%3A

## mail-notification.svg
- Created by: Google
- License: Apache License, Version 2.0
- Link: https://fonts.google.com/icons?selected=Material%20Icons%3Aemail%3A

