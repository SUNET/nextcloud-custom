<?php

$appId = OCA\OpenAi\AppInfo\Application::APP_ID;
\OCP\Util::addScript($appId, $appId . '-imageGenerationPage');
