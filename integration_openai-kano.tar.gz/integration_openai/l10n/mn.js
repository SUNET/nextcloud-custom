OC.L10N.register(
    "integration_openai",
    {
    "Unknown" : "Үл танигдах зүйл",
    "seconds" : "секунд",
    "Preview" : "шалгах",
    "Advanced options" : "Бусад сонголтууд",
    "Send" : "илгээх",
    "Unknown error" : "үл мэдэгдэх алдаа",
    "Translate" : "Орчуулга"
},
"nplurals=2; plural=(n != 1);");
