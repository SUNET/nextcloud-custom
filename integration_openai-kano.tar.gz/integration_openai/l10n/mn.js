OC.L10N.register(
    "integration_openai",
    {
    "Preview" : "шалгах",
    "Advanced options" : "Бусад сонголтууд",
    "Send" : "илгээх",
    "Unknown error" : "үл мэдэгдэх алдаа",
    "Translate" : "Орчуулга"
},
"nplurals=2; plural=(n != 1);");
