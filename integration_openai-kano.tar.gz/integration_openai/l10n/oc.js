OC.L10N.register(
    "integration_openai",
    {
    "Unknown" : "Desconegut",
    "seconds" : "segondas",
    "Bad credentials" : "Marrits identificants",
    "Connected accounts" : "Comptes connectats",
    "Preview" : "Apercebut",
    "Advanced options" : "Opcions avançadas",
    "Send" : "Enviar",
    "Unknown error" : "Error desconeguda"
},
"nplurals=2; plural=(n > 1);");
