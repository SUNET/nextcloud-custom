OC.L10N.register(
    "integration_openai",
    {
    "Unknown" : "Disconnotu",
    "seconds" : "segundos",
    "Bad HTTP method" : "Mètodu HTTP no bàlidu",
    "Bad credentials" : "Credentziales non bàlidas",
    "Connected accounts" : "Contos connètidos",
    "Request timeout (seconds)" : "Tempus màssimu de sa rechesta (segundos)",
    "API key" : "Crae API",
    "Advanced options" : "Sèberos avantzados",
    "Result" : "Resurtadu",
    "Unknown error" : "Errore disconnotu",
    "Translate" : "Borta"
},
"nplurals=2; plural=(n != 1);");
