OC.L10N.register(
    "integration_openai",
    {
    "Bad HTTP method" : "Mètodu HTTP no bàlidu",
    "Bad credentials" : "Credentziales non bàlidas",
    "Connected accounts" : "Contos connètidos",
    "Request timeout (seconds)" : "Tempus màssimu de sa rechesta (segundos)",
    "Advanced options" : "Sèberos avantzados",
    "Result" : "Resurtadu",
    "Unknown error" : "Errore disconnotu",
    "Translate" : "Borta"
},
"nplurals=2; plural=(n != 1);");
