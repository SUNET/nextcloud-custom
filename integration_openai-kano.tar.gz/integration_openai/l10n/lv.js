OC.L10N.register(
    "integration_openai",
    {
    "Unknown" : "Nezināms",
    "seconds" : "sekundes",
    "API key" : "API atslēga",
    "Preview" : "Priekšskatīt",
    "Advanced options" : "Papildu opcijas",
    "Send" : "Sūtīt",
    "Unknown error" : "Nezināma kļūda",
    "Translate" : "Tulkot"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
