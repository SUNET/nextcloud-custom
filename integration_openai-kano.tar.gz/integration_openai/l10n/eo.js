OC.L10N.register(
    "integration_openai",
    {
    "Request timeout (seconds)" : "Eltempiĝo (sekundoj)",
    "Preview" : "Antaŭvidi",
    "Advanced options" : "Detalaj agordoj",
    "Send" : "Sendi",
    "Unknown error" : "Nekonata eraro",
    "Translate" : "Traduku"
},
"nplurals=2; plural=(n != 1);");
