OC.L10N.register(
    "integration_openai",
    {
    "Unknown" : "Nekonata",
    "seconds" : "sekundoj",
    "Request timeout (seconds)" : "Eltempiĝo (sekundoj)",
    "API key" : "API-ŝlosilo",
    "Preview" : "Antaŭvidi",
    "Advanced options" : "Detalaj agordoj",
    "Send" : "Sendi",
    "Unknown error" : "Nekonata eraro",
    "Translate" : "Traduku"
},
"nplurals=2; plural=(n != 1);");
