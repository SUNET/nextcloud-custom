OC.L10N.register(
    "integration_openai",
    {
    "Preview" : "Eelvaade",
    "Advanced options" : "Täpsemad valikud",
    "Send" : "Saada",
    "Unknown error" : "Tundmatu viga",
    "Translate" : "Tõlgi"
},
"nplurals=2; plural=(n != 1);");
