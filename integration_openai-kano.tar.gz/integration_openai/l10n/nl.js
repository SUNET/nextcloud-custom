OC.L10N.register(
    "integration_openai",
    {
    "Bad HTTP method" : "Foute HTTP methode",
    "Bad credentials" : "Foute inloggegevens",
    "Connected accounts" : "Verbonden accounts",
    "Request timeout (seconds)" : "Aanvraag time-out (seconds)",
    "Preview" : "Voorbeeld",
    "Advanced options" : "Geavanceerde opties",
    "Send" : "Verzenden",
    "Result" : "Resultaat",
    "Unknown error" : "Onbekende fout",
    "Translate" : "Vertaal"
},
"nplurals=2; plural=(n != 1);");
