OC.L10N.register(
    "integration_openai",
    {
    "Connected accounts" : "Forbundne konti",
    "Request timeout (seconds)" : "Anmodning timeout (sekunder)",
    "Preview" : "Forhåndsvisning",
    "Advanced options" : "Avancerede indstillinger",
    "Send" : "Send",
    "Result" : "Resultat",
    "Unknown error" : "Ukendt fejl",
    "Translate" : "Oversæt"
},
"nplurals=2; plural=(n != 1);");
