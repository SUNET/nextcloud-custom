OC.L10N.register(
    "integration_openai",
    {
    "Request timeout (seconds)" : "Kohë skadimi kërkese (sekonda)",
    "Preview" : "Parapamje ",
    "Advanced options" : "Opsione të avancuara",
    "Send" : "Dërgo",
    "Result" : "Rezultatet",
    "Unknown error" : "Gabim i panjohur",
    "Translate" : "Përkthe"
},
"nplurals=2; plural=(n != 1);");
