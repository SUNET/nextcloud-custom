OC.L10N.register(
    "integration_openai",
    {
    "Unknown" : "I panjohur",
    "seconds" : "sekonda",
    "Request timeout (seconds)" : "Kohë skadimi kërkese (sekonda)",
    "API key" : "Kyç API",
    "Preview" : "Parapamje ",
    "Advanced options" : "Opsione të avancuara",
    "Send" : "Dërgo",
    "Result" : "Rezultatet",
    "Unknown error" : "Gabim i panjohur",
    "Translate" : "Përkthe"
},
"nplurals=2; plural=(n != 1);");
