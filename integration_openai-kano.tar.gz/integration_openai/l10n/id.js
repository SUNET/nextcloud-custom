OC.L10N.register(
    "integration_openai",
    {
    "Bad HTTP method" : "Metode HTTP tidak benar",
    "Bad credentials" : "Kredensial tidak benar",
    "Connected accounts" : "Akun terhubung",
    "Request timeout (seconds)" : "Minta waktu habis (detik)",
    "Preview" : "Pratinjau",
    "Advanced options" : "Opsi lanjutan",
    "Send" : "Kirim",
    "Unknown error" : "Kesalahan tidak diketahui",
    "Translate" : "Terjemahkan"
},
"nplurals=1; plural=0;");
