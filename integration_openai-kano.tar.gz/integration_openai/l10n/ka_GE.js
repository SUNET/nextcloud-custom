OC.L10N.register(
    "integration_openai",
    {
    "Request timeout (seconds)" : "მოთხოვნის დროის ამოწურვა (წამები)",
    "Preview" : "წინასწარი ჩვენება",
    "Advanced options" : "დამატებითი ოპციონები",
    "Send" : "გაგზავნა",
    "Result" : "შედეგი",
    "Unknown error" : "უცნობი შეცდომა",
    "Translate" : "გადათარგმნეთ"
},
"nplurals=2; plural=(n!=1);");
