OC.L10N.register(
    "integration_openai",
    {
    "Bad credentials" : "不正な資格情報",
    "Connected accounts" : "接続済みアカウント",
    "Request timeout (seconds)" : "リクエストがタイムアウトするまでの秒数",
    "Image generation" : "画像の生成",
    "Preview" : "プレビュー",
    "Advanced options" : "詳細オプション",
    "Send" : "送信",
    "Result" : "結果",
    "Unknown error" : "不明なエラー",
    "Translate" : "翻訳"
},
"nplurals=1; plural=0;");
