OC.L10N.register(
    "integration_openai",
    {
    "Connected accounts" : "සම්බන්ධිත ගිණුම්",
    "Preview" : "පෙරදසුන",
    "Send" : "යවන්න",
    "Unknown error" : "නොදන්නා දෝෂයකි",
    "Translate" : "පරිවර්තනය"
},
"nplurals=2; plural=(n != 1);");
