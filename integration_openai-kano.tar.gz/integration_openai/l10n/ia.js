OC.L10N.register(
    "integration_openai",
    {
    "Unknown" : "Incognite",
    "seconds" : "secundas",
    "API key" : "Clave API",
    "Preview" : "Previsualisar",
    "Advanced options" : "Optiones avantiate",
    "Send" : "Inviar",
    "Unknown error" : "Error incognite"
},
"nplurals=2; plural=(n != 1);");
