OC.L10N.register(
    "integration_openai",
    {
    "Bad credentials" : "Gölluð auðkenni",
    "Connected accounts" : "Tengdir aðgangar",
    "Request timeout (seconds)" : "Tímamörk á beiðni (sekúndur)",
    "Preview" : "Forskoðun",
    "Advanced options" : "Ítarlegir valkostir",
    "Send" : "Senda",
    "Result" : "Niðurstöður",
    "Unknown error" : "Óþekkt villa",
    "Translate" : "Þýða"
},
"nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);");
