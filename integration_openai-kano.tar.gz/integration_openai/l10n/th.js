OC.L10N.register(
    "integration_openai",
    {
    "Request timeout (seconds)" : "หมดเวลาคำขอ (วินาที)",
    "Preview" : "ตัวอย่าง",
    "Advanced options" : "ตัวเลือกขั้นสูง",
    "Send" : "ส่ง",
    "Unknown error" : "ข้อผิดพลาดที่ไม่รู้จัก",
    "Translate" : "แปลภาษา"
},
"nplurals=1; plural=0;");
