OC.L10N.register(
    "integration_openai",
    {
    "Bad HTTP method" : "Phương thức HTTP không hợp lệ",
    "Image generation" : "Tạo hình ảnh",
    "Preview" : "Xem trước",
    "Advanced options" : "Tùy chọn nâng cao",
    "Send" : "Gửi",
    "Unknown error" : "Lỗi không xác định",
    "Translate" : "Dịch"
},
"nplurals=1; plural=0;");
