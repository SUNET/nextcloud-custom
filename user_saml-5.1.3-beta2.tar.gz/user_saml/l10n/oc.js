OC.L10N.register(
    "user_saml",
    {
    "Saved" : "Enregistrat",
    "Email address" : "Adreça mail",
    "Encrypted" : "Chifrat",
    "Open documentation" : "Dobrir la documentacion",
    "Global settings" : "Paramètres globals",
    "General" : "Generals",
    "Security settings" : "Paramètres de seguretat",
    "Error" : "Error"
},
"nplurals=2; plural=(n > 1);");
