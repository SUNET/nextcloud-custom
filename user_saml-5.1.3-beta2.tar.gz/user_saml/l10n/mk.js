OC.L10N.register(
    "user_saml",
    {
    "Saved" : "Зачувано",
    "Email address" : "Е-пошта адреси",
    "Open documentation" : "Отвори ја документацијата",
    "General" : "Општо",
    "Error" : "Грешка"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
