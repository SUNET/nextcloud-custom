# nextcloud-sql_app_password_manager
Manage app passwords in an external sql database

Some quick notes for my self
```
db_host =
db_user =
db_password =
db_name =
---
insert =

bind_parameters =
hash_function =
hash_parameter =
---
select =
bind_parameters =
 
---
delete =

bind_parameters =
---
```

RUN:
```
docker run --name nextcloud -p 8080:80 -d \
-v ./html:/var/www/html \
nextcloud
cd html
git clone git@github.com:SUNET/nextcloud_sql_app_password_manager.git sql_app_password_manager
```

## Screenshots
![Admin settings](https://raw.githubusercontent.com/SUNET/nextcloud_sql_app_password_manager/main/screenshots/admin.png)
![Personal settings](https://raw.githubusercontent.com/SUNET/nextcloud_sql_app_password_manager/main/screenshots/personal.png)
