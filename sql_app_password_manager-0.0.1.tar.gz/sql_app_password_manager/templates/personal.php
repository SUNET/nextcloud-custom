<?php
// SPDX-FileCopyrightText: Micke Nordin <kano@sunet.se>
// SPDX-License-Identifier: AGPL-3.0-or-later

/** @var \OCP\IL10N $l */
/** @var array $_ */
script('sql_app_password_manager', 'personal');
?>

<div id="sql_app_password_manager_personal" class="section">
  <h2>External SQL App Passwords</h2>
  <table style="border-spacing: 3px !important">
    <thead>
      <tr>
        <th>ID</th>
        <th>Device</th>
        <th></th>
      </tr>
    </thead>
    <tbody class="token-list" id="sql-token-tbody">
    </tbody>
  </table>
  <div id="sql_form">
    <form>
      <input type="text" id="appid_name" placeholder="Device name"></input>
      <button type="button" id="sql-create-button" class="appid_submit">Generate App Password</button>
    </form>
  </div>
</div>
