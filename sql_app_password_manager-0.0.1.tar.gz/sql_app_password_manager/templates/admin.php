<?php
// SPDX-FileCopyrightText: Micke Nordin <kano@sunet.se>
// SPDX-License-Identifier: AGPL-3.0-or-later

/** @var \OCP\IL10N $l */
/** @var array $_ */
script('sql_app_password_manager', 'admin');
?>

<div id="SQLAppPasswordManagerSettings" class="section">
  <h2 class="settings-section">App Password Manager Settings</h2>
  <table>
    <tr>
      <th>Config option</th>
      <th>Exampel</th>
    </tr>
    <tr>
      <td>db_hosts</td>
      <td>example1.host.tld:3306,example2.host.tld</td>
    </tr>
    <tr>
      <td>db_user</td>
      <td>my_cool_user</td>
    </tr>
    <tr>
      <td>db_password</td>
      <td>VeryS3cr3tP@ssw0rd!</td>
    </tr>
    <tr>
      <td>db_name</td>
      <td>cool_database_name</td>
    </tr>
    <tr>
      <td>db_name</td>
      <td>my_table</td>
    </tr>
    <tr>
      <td>bind_parameters</td>
      <td>column1=%UID%,column2=%EMAIL%,column3=%CLOUDID%,column4=%DISPLAYNAME%,column5=%PASSWORD%</td>
    </tr>
  </table>
  <br />
  <p>
    Bind parameters are templates that will automatically be replaced like this:
  </p>
  <pre>
  '%CLOUDID%' => $this->user->getCloudId()
  '%DISPLAYNAME%' => $this->user->getDisplayName()
  '%EMAIL%' => $this->user->getEMailAddress()
  '%UID%' => $this->user->getUid()
  '%PASSWORD%' => Random app password
  </pre
  <form id="sql-app-password-manager-settings">
    <label for="db_hosts">
      Database hosts
    </label>
    <br />
    <input type="text" name="db_hosts" id="db_hosts" class="text" value="<?php print_unescaped($_["db_hosts"]); ?>" placeholder="comma separated list of database hosts" style="width: auto !important" />
    <br />
    <label for="db_user">
      Database user
    </label>
    <br />
    <input type="text" name="db_user" id="db_user" class="text" value="<?php print_unescaped($_["db_user"]); ?>" placeholder="database user" style="width: auto !important" />
    <br />
    <label for="db_password">
      Database password
    </label>
    <br />
    <input type="password" name="db_password" id="db_password" class="password" value="<?php print_unescaped($_["db_password"]); ?>" placeholder="database password" style="width: auto !important" />
    <br />
    <label for="db_name">
      Database name
    </label>
    <br />
    <input type="text" name="db_name" id="db_name" class="text" value="<?php print_unescaped($_["db_name"]); ?>" placeholder="database name" style="width: auto !important" />
    <br />
    <label for="db_table">
      Database table
    </label>
    <br />
    <input type="text" name="db_table" id="db_table" class="text" value="<?php print_unescaped($_["db_table"]); ?>" placeholder="database table" style="width: auto !important" />
    <br />
    <label for="bind_parameters">
      Bind parameters
    </label>
    <br />
    <input type="text" name="bind_parameters" id="bind_parameters" class="text" value="<?php print_unescaped($_["bind_parameters"]); ?>" placeholder="bind parameters" style="width: auto !important" />
    <br />
    <input id="db_submit" type="button" class="button" value="Save">
    <span class="msg"></span>
  </form>
</div>
