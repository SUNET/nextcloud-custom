const path = require("path");
const webpack = require("webpack");
const webpackConfig = require("@nextcloud/webpack-vue-config");
//const axios = require("@nextcloud/axios");

webpackConfig.entry = {
  admin: "./src/settings-admin.js",
  personal: "./src/settings-personal.js",
};

webpackConfig.output = {
  filename: "[name].js",
  path: path.resolve(__dirname, "js"),
};

webpackConfig.plugins.push(
  new webpack.ProvidePlugin({
    $: "jquery",
    jQuery: "jquery",
  }),
);

//webpackConfig.plugins.push(axios);

module.exports = webpackConfig;
