<?php
declare(strict_types=1);

/**
 * @copyright Copyright (c) 2023 Micke Nordin <kano@sunet.se>
 *
 * @author Micke Nordin <kano@sunet.se>
 *
 * @license GNU AGPL version 3 or any later version
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 *
 */


namespace OCA\SQLAppPasswordManager\Settings;

use OCP\AppFramework\Http\TemplateResponse;
use OCP\IConfig;
use OCP\Settings\ISettings;

class AdminSettings implements ISettings
{

  /** @var IConfig */
  private $config;

  /**
   * Admin constructor.
   *
   * @param IConfig $config
   */
  public function __construct(IConfig $config)
  {
    $this->config = $config;
  }

  /**
   * @return TemplateResponse
   */
  public function getForm()
  {

    $db_hosts = $this->config->getAppValue('sql_app_password_manager', 'db_hosts', '');
    $db_user = $this->config->getAppValue('sql_app_password_manager', 'db_user', '');

    $db_password = $this->config->getAppValue('sql_app_password_manager', 'db_password', '');
    $db_name = $this->config->getAppValue('sql_app_password_manager', 'db_name', '');
    $db_table = $this->config->getAppValue('sql_app_password_manager', 'db_table', '');
    $bind_parameters = $this->config->getAppValue('sql_app_password_manager', 'bind_parameters', '');
    //$conn_string = sprintf('mysql://%s:%s@%s/%s', $db_user, $db_password, $db_hosts,$db_name);
    $parameters = [];
    $parameters['db_hosts'] = $db_hosts;
    $parameters['db_user'] = $db_user;
    $parameters['db_password'] = $db_password;
    $parameters['db_name'] = $db_name;
    $parameters['db_table'] = $db_table;
    $parameters['bind_parameters'] = $bind_parameters;
    return new TemplateResponse('sql_app_password_manager', 'admin', $parameters);
  }

  /**
   * @return string the section ID, e.g. 'sharing'
   */
	public function getSection(): string {
		return 'security';
	}

  /**
   * @return int whether the form should be rather on the top or bottom of
   * the admin section. The forms are arranged in ascending order of the
   * priority values. It is required to return a value between 0 and 100.
   */
  public function getPriority()
  {
    return 50;
  }
}
