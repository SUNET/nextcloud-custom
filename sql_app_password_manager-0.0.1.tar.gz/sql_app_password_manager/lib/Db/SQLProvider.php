<?php

declare(strict_types=1);

/**
 * @copyright Copyright (c) 2023 Micke Nordin <kano@sunet.se>
 *
 * @author Micke Nordin <kano@sunet.se> 
 *
 * @license GNU AGPL version 3 or any later version
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 *
 */


namespace OCA\SQLAppPasswordManager\Db;

use OCP\IConfig;
use OCP\IUser;
use PDO;

class SQLProvider
{
  private PDO $conn;
  private IConfig $config;
  private IUser $user;
  public function __construct(
    IConfig $config,
    IUser $user,
  ) {

    $this->config = $config;
    $this->conn = new PDO($this->get_connstring(), $this->get_db_user(), $this->get_db_password());
    $this->user = $user;
  }

  public function __destruct()
  {
    $this->conn = null;
  }
  private function get_connstring(): string
  {
    $db_hosts = $this->config->getAppValue('sql_app_password_manager', 'db_hosts');
    $db_name = $this->config->getAppValue('sql_app_password_manager', 'db_name');
    $conn_string = sprintf('mysql:dbname=%s;host=%s', $db_name, $db_hosts);
    return $conn_string;
  }
  private function get_db_user(): string
  {
    return $this->config->getAppValue('sql_app_password_manager', 'db_user');
  }
  private function get_db_table(): string
  {
    return $this->config->getAppValue('sql_app_password_manager', 'db_table');
  }
  private function get_db_password(): string
  {
    return $this->config->getAppValue('sql_app_password_manager', 'db_password');
  }
  private function resolve_template(string $template_value): string
  {
    return  match ($template_value) {
      '%CLOUDID%' => $this->user->getCloudId(),
      '%PASSWORD%' => base64_encode(random_bytes(42)),
      '%DISPLAYNAME%' => $this->user->getDisplayName(),
      '%EMAIL%' => $this->user->getEMailAddress(),
      '%UID%' => $this->user->getUid(),
      default => '',
    };
  }

  private function get_params(bool $for_select = false): array
  {
    $bind_parameters = $this->config->getAppValue('sql_app_password_manager', 'bind_parameters');
    $temp_params = explode(',', $bind_parameters);
    $loop_params = [];
    foreach ($temp_params as $param) {
      $split = explode('=', $param, 2);
      $loop_params[$split[0]] = $split[1];
    }
    $params = [];
    foreach ($loop_params as $pkey => $pvalue) {
      $key = $pkey;
      if ($for_select) {
        if ($pvalue == "%PASSWORD%") {
          continue;
        }
      }
      $value = $this->resolve_template($pvalue);
      $params[$key] = $value;
    }
    return $params;
  }
  public function delete(int $id): bool
  {
    $table = $this->get_db_table();
    $query = "DELETE FROM " . $table . " WHERE id = " . (string) $id;
    $stmt = $this->conn->prepare($query);
    return $stmt->execute();
  }
  public function insert(string $name): array
  {
    $table = $this->get_db_table();
    $params = $this->get_params();
    $plaintext = $params['password'];
    $crypt = crypt($plaintext, '$6$' . base64_encode(random_bytes(16)) . '$');
    $hash = hash('sha512', $plaintext);
    $params['hash'] = $hash;
    $params['password'] = $crypt;
    $params['comment'] = $name;
    $query = "INSERT INTO " . $table;
    $columns = "(";
    $values = "(";

    foreach ($params as $key => $value) {
      $columns .= $key . ", ";
      $values .= ':' . $key . ', ';
    }
    $columns = rtrim($columns, " ,");
    $values = rtrim($values, " ,");
    $query .= $columns . ") VALUES" . $values . ")";
    $stmt = $this->conn->prepare($query);
    foreach ($params as $key => $value) {
      $stmt->bindValue(':' . $key, $value, PDO::PARAM_STR);
    }
    $password = "";
    if ($stmt->execute()) {
      $password = $plaintext;
    }
    return array("password" => $password);
  }
  public function select(): array
  {
    $table = $this->get_db_table();
    $params = $this->get_params(true);
    $query = "SELECT id, comment as name FROM " . $table . " WHERE ";
    foreach ($params as $key => $value) {
      $query .= $key . " = " . ":" . $key . " AND ";
    }
    $query = rtrim($query, " AND ");
    $stmt = $this->conn->prepare($query);
    foreach ($params as $key => $value) {
      $stmt->bindParam(':' . $key, $value);
    }
    $stmt->execute();
    $result = $stmt->fetchAll();
    return $result;
  }
}
