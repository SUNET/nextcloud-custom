<?php

declare(strict_types=1);

/**
 * @copyright 2023 Micke Nordin <kano@sunet.se>
 *
 * @author 2023 Micke Nordin <kano@sunet.se>
 *
 * @license GNU AGPL version 3 or any later version
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

namespace OCA\SQLAppPasswordManager\Controller;

use OCA\SQLAppPasswordManager\AppInfo\Application;
use OCP\AppFramework\Controller;
use OCP\AppFramework\Http\Attribute\CORS;
use OCP\AppFramework\Http\Attribute\NoCSRFRequired;
use OCP\IConfig;
use OCP\IRequest;
class AdminController extends Controller
{
  private IConfig $config;
  public function __construct(
    IRequest $request,
    IConfig $config,
  ) {
    parent::__construct(Application::APP_ID, $request);
    $this->config = $config;
  }
  
  #[CORS]
  #[NoCSRFRequired]
  public function settings(array $data)
  {
    $db_hosts = $data['db_hosts'];
    $db_user = $data['db_user'];
    $db_password = $data['db_password'];
    $db_name = $data['db_name'];
    $db_table = $data['db_table'];
    $bind_parameters = $data['bind_parameters'];
    $this->config->setAppValue('sql_app_password_manager', 'db_hosts', $db_hosts);
    $this->config->setAppValue('sql_app_password_manager', 'db_user', $db_user);
    $this->config->setAppValue('sql_app_password_manager', 'db_password', $db_password);
    $this->config->setAppValue('sql_app_password_manager', 'db_name', $db_name);
    $this->config->setAppValue('sql_app_password_manager', 'db_table', $db_table);
    $this->config->setAppValue('sql_app_password_manager', 'bind_parameters', $bind_parameters);
  }
}
