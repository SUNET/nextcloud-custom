// SPDX-FileCopyrightText: Enrique Pérez Arnaud <eperez@emergya.com>, Micke Nordin <kano@sunet.se>
// SPDX-License-Identifier: AGPL-3.0-or-later
import axios from "@nextcloud/axios";
import { generateUrl } from "@nextcloud/router";
$(document).ready(function () {
  $("#db_submit").on("click", function (event) {
    var data = {};
    event.preventDefault();
    OC.msg.startSaving("#sql-app-password-manager-settings .msg");

    const ids = [
      "db_hosts",
      "db_user",
      "db_password",
      "db_name",
      "db_table",
      "bind_parameters",
    ];
    ids.forEach((element) => {
      var param = $("#" + element);
      data[param.attr("name")] = param.val();
    });
    console.log(data);
    const base_url = generateUrl("/apps/sql_app_password_manager");
    //const base_url = generateUrl("/ocs/v2.php/apps/provisioning_api/api/v1/config/apps/sql_app_password_manager/");
    axios.defaults.baseURL = base_url;
    axios
      .post("admin", { data: data })
      .then(function (result) {
        console.log(result.response.data);
      })
      .catch(function (error) {
        console.log(error.response.data);
      });
    OC.msg.finishedSaving("#sql-app-password-manager-settings .msg", {
      status: "success",
      data: { message: t("sql_app_password_manager", "Saved.") },
    });
  });
});
