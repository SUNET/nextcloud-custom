// SPDX-FileCopyrightText: Enrique Pérez Arnaud <eperez@emergya.com>, Micke Nordin <kano@sunet.se>
// SPDX-License-Identifier: AGPL-3.0-or-later
import axios from "@nextcloud/axios";
import { generateUrl } from "@nextcloud/router";

async function run_request(method, data = {}) {
  const url = "user";
  const base_url = generateUrl("/apps/sql_app_password_manager");
  axios.defaults.baseURL = base_url;

  var result;
  try {
    switch (method) {
      case "GET":
        result = await axios.get(url);
        break;
      case "POST":
        result = await axios.post(
          url,
          { data: data },
          {
            headers: {
              "Content-Type": "application/json",
            },
          }
        );
        break;
      case "DELETE":
        result = await axios.delete(url, { data: data });
        break;
      default:
        console.log(`Unknown method: ${method}`);
    }
    return result.data;
  } catch (error) {
    console.log(error.response.data);
    return [];
  }
}

function populate() {
  var pre_existing = document.getElementById("copy_button");
  if (pre_existing) {
    pre_existing.remove();
  }
  run_request("GET")
    .then(function(response) {
      var current_data = response;
      var tbody = document.getElementById("sql-token-tbody");
      tbody.innerHTML = null;
      current_data.forEach((element) => {
        var row = tbody.insertRow();
        var id_cell = row.insertCell();
        var name_cell = row.insertCell();
        var button_cell = row.insertCell();
        var button = document.createElement("button");
        button.textContent = "Delete";
        button.value = element.id;
        button.type = "button";
        button.id = "sql-delete-" + element.id;
        button.classList.add("appid_delete");
        button.addEventListener("click", function(event) {
          event.preventDefault();
          var value = event.target.value;
          delete_callback(value);
        });
        button_cell.appendChild(button);
        var id_label = document.createTextNode(element.id);
        var name_label = document.createTextNode(element.name);
        id_cell.appendChild(id_label);
        name_cell.appendChild(name_label);
      });
    })
    .catch(function(error) {
      console.log(error);
    });
}
function delete_callback(value) {
  var data = { data: { id: parseInt(value) } };
  run_request("DELETE", data)
    .then(function(response) {
      console.log(response);
    })
    .catch(function(error) {
      console.log(error);
    });
  populate();
}

$(document).ready(function() {
  populate();
  $(".appid_submit").on("click", function(event) {
    event.preventDefault();
    var data = { name: document.getElementById("appid_name").value };

    run_request("POST", data)
      .then(function(response) {
        var form_div = document.getElementById("sql_form");
        var pre_existing = document.getElementById("copy_button");
        if (pre_existing) {
          pre_existing.remove();
        }
        var button = document.createElement("button");
        button.id = "copy_button";
        button.textContent = "Copy password";
        button.type = "button";
        button.value = response.password;
        button.addEventListener("click", function(event) {
          event.preventDefault();
          var value = event.target.value;
          navigator.clipboard.writeText(value);
          event.target.remove();
        });
        form_div.appendChild(button);
      })
      .catch(function(error) {
        console.log(error);
      });
    populate();
  });
});
