OC.L10N.register(
    "user_saml",
    {
    "Saved" : "تم الإحتفاظ به",
    "Provider" : "المزوّد",
    "Provider " : "المزوّد",
    "Private key of the Service Provider" : "المفتاح الشخصي لموفر الخدمة",
    "Email address" : "عنوان البريد الإلكتروني",
    "Encrypted" : "مشفّر",
    "SSO & SAML authentication" : "المصادقة عبر SSO و SAML",
    "Open documentation" : "فتح الدليل",
    "Global settings" : "الإعدادات العامة",
    "General" : "العامة",
    "Identity Provider Data" : "مُزوِّد بيانات الهوية",
    "Security settings" : "الإعدادات الأمنية",
    "Show security settings…" : "إظهار إعدادات الأمان …",
    "Error" : "خطأ"
},
"nplurals=6; plural=n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 && n%100<=99 ? 4 : 5;");
