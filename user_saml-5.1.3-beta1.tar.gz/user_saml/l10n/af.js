OC.L10N.register(
    "user_saml",
    {
    "Saved" : "Bewaar",
    "Provider" : "Verskaffer",
    "Provider " : "Verskaffer",
    "Private key of the Service Provider" : "Privaatsleutel van die Diensverskaffer",
    "Open documentation" : "Open dokumentasie",
    "Remove identity provider" : "Verwyder identiteitsverskaffer",
    "Add identity provider" : "Voeg identiteitsverskaffer toe",
    "General" : "Algemeen",
    "Service Provider Data" : "Diensverskafferdata",
    "Identity Provider Data" : "Identiteitsverskafferdata",
    "Security settings" : "Sekuriteitsinstellings",
    "Signatures and encryption offered" : "Handtekeninge en enkripsie gebied",
    "Signatures and encryption required" : "Handtekeninge en enkripsie vereis",
    "Download metadata XML" : "Laai metadata XML af",
    "Metadata invalid" : "Metadata ongeldig",
    "Metadata valid" : "Metadata geldig",
    "Error" : "Fout"
},
"nplurals=2; plural=(n != 1);");
