OC.L10N.register(
    "user_saml",
    {
    "Saved" : "Đã lưu",
    "Email address" : "Địa chỉ thư điện tử",
    "Encrypted" : "Đã mã hóa",
    "Open documentation" : "Mở tài liệu",
    "General" : "Tổng hợp",
    "Error" : "Lỗi"
},
"nplurals=1; plural=0;");
