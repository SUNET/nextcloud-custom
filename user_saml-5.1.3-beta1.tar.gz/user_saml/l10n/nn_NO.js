OC.L10N.register(
    "user_saml",
    {
    "Saved" : "Lagra",
    "Encrypted" : "Kryptert",
    "Open documentation" : "Opne dokumentasjon",
    "General" : "Generelt",
    "Error" : "Feil"
},
"nplurals=2; plural=(n != 1);");
