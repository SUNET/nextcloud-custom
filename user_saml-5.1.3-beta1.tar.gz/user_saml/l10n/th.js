OC.L10N.register(
    "user_saml",
    {
    "This user account is disabled, please contact your administrator." : "บัญชีผู้ใช้นี้ถูกปิดการใช้งาน กรุณาติดต่อผู้ดูแลระบบ",
    "Saved" : "บันทึกแล้ว",
    "Provider" : "ผู้ให้บริการ",
    "Email address" : "ที่อยู่อีเมล",
    "Open documentation" : "เปิดเอกสารประกอบ",
    "General" : "ทั่วไป",
    "Error" : "ข้อผิดพลาด"
},
"nplurals=1; plural=0;");
